#pragma once

#include "qlogicae_core.hpp"
#include "qlogicae_plotica.hpp"
