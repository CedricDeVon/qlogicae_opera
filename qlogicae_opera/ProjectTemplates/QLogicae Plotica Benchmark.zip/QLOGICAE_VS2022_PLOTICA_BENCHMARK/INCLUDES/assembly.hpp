#pragma once

namespace QLogicaeVS2022PloticaBenchmark
{

}
