#pragma once

namespace QLogicaePloticaBenchmark
{

}
