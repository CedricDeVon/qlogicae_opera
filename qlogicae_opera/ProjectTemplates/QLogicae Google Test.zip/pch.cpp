#include "pch.hpp"

#ifndef x64_MASM_ASSEMBLY

extern "C" void qlogicae_test__assembly();

#endif
