#pragma once

#include "qlogicae_core.hpp"

#include "gtest/gtest.h"
