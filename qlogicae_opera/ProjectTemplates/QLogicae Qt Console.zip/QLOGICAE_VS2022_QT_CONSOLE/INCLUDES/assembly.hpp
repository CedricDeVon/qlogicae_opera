#pragma once

namespace QLogicaeVS2022QtConsole
{

}
