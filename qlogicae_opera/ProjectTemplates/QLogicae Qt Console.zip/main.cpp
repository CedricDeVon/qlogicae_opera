#include "pch.hpp"

#include "main.hpp"

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    return app.exec();
}

namespace QLogicaeVS2022QtConsole
{

}
