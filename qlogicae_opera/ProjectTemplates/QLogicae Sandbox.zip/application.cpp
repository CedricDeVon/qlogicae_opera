#include "pch.hpp"

#include "application.hpp"

#ifndef x64_MASM_ASSEMBLY

extern "C" void qlogicae_sandbox__assembly();

#endif

namespace QLogicaeSandbox
{

}
