#pragma once

namespace QLogicaeSandbox
{

}
