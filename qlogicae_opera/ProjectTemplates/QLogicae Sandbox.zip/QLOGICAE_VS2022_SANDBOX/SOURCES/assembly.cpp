#include "pch.hpp"

#include "../includes/assembly.hpp"

#ifndef x64_MASM

extern "C" void x64_masm__main();

#endif

namespace QLogicaeVS2022Sandbox
{

}
