#include "pch.hpp"

#include "../includes/all.hpp"

namespace QLogicaeVS2022Sandbox
{

}
