#pragma once

#include "qlogicae_vs2022_qt_test/includes/application.hpp"

namespace QLogicaeVS2022QtTest
{

}
