
<h1>Legalities</h1>

<p>> <a href="../../../README.md">Home</a> > <a href="./index.md">Index</a></p>

</br>

