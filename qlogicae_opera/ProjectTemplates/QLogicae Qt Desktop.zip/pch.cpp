#include "pch.hpp"

namespace QLogicaeVS2022QtDesktop
{

}
