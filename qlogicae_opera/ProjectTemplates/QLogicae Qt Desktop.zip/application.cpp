#include "stdafx.h"

#include "application.hpp"

#ifndef x64_MASM_ASSEMBLY

extern "C" void qlogicae_qt_gui__assembly();

#endif

namespace QLogicaeQtGUI
{
    Application::Application(QWidget* parent)
        : QMainWindow(parent)
    {
        ui.setupUi(this);
    }

    Application::~Application()
    {

    }
}
