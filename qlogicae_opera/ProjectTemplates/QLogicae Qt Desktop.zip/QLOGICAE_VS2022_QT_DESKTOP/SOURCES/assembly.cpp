#include "pch.hpp"

#include "../includes/assembly.hpp"

#ifndef x64_MASM_ASSEMBLY

extern "C" void x64_masm__main();

#endif

namespace QLogicaeVS2022QtDesktop
{

}
