#include "pch.hpp"

#include "../includes/utilities.hpp"

namespace QLogicaeVS2022QtDesktop
{

}
