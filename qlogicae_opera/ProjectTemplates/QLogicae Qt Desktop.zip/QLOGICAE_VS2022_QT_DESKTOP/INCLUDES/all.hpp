#pragma once

#include "assembly.hpp"
#include "utilities.hpp"

#include "application.hpp"

namespace QLogicaeVS2022QtDesktop
{

}
