#pragma once

namespace QLogicaeVS2022DynamicallyLinkedLibrary
{

}
