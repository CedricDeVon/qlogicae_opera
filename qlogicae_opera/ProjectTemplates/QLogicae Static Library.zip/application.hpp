#pragma once

namespace QLogicaeStaticLibrary
{

}
