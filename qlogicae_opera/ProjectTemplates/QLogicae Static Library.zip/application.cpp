#include "pch.hpp"

#include "application.hpp"

#ifndef x64_MASM_ASSEMBLY

extern "C" void qlogicae_static_library__assembly();

#endif

namespace QLogicaeStaticLibrary
{

}
