#pragma once

#include "assembly.hpp"

namespace QLogicaeVS2022StaticLibrary
{

}
