#pragma once

#include "framework.h"

#include "qlogicae_core.hpp"
