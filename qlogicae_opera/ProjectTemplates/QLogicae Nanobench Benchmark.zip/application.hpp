#pragma once

namespace QLogicaeNanobenchBenchmark
{

}
