#include "pch.hpp"

#include "../includes/application.hpp"

namespace QLogicaeVS2022Console
{

}
