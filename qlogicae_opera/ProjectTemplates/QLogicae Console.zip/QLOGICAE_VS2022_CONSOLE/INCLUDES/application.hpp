#pragma once

#include "utilities.hpp"

namespace QLogicaeVS2022Console
{

}
