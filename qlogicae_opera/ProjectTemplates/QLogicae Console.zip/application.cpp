#include "pch.hpp"

#include "application.hpp"

#ifndef x64_MASM_ASSEMBLY

extern "C" void qlogicae_console__assembly();

#endif

namespace QLogicaeConsoleApplication
{

}
