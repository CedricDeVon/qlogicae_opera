#pragma once

#include "qlogicae_vs2022_qt_static_library/includes/application_global.hpp"

namespace QLogicaeVS2022QtStaticLibrary
{
    class QLOGICAE_QT_STATIC_LIBRARY_APPLICATION_EXPORT Application
    {
    public:
        Application();
    };
}
