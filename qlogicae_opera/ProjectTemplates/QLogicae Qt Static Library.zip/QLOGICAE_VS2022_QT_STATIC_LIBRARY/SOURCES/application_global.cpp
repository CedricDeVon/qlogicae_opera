#include "pch.hpp"

#include "../includes/application_global.hpp"

namespace QLogicaeVS2022QtStaticLibrary
{

}
